ChihanaGBK v2.4.0.0  (2026-11-27)
version.dll  MD5 = cae2d4bc7990df37109e06d5de22323c   大小 = 52736 位元組
（檔案屬性 → 詳細資料 可看到版本號與功能說明；Debug=1 時 log 第一行也會寫出版本）

【用途】Kaguya 引擎遊戲，在「轉簡中」(Locale Emulator) 下正確顯示 GBK 文字；原版 exe 不被修改。
【使用】version.dll 與 ChihanaGBK.ini 放到遊戲資料夾（與 exe 同一層）。需要 exe 匯入 VERSION.dll。

【已驗證的遊戲 / 版本】（靜態分析 + 模擬器執行編譯後的 DLL 碼；尚未在真機實測）
  A000.exe           params v5.8（舊編譯器）   reader 0x40BA50
  B000.exe=4328.exe  params v5.7              reader 0x40C010
  h000.exe(Hakoniwa) params v5.8（新編譯器）   reader 0x41C6C0
【不保證】params v5.4/v5.5（走舊的資源讀取路徑，結構不同）、其他編譯器配置；掃不到時只略過標題/標點修補，字型與編碼規則照常運作。
【不適用】已經把 exe 字串轉成 GBK 的版本（如 B001.exe）：其 WideCharToMultiByte 規則與本 DLL 不合。

【功能】
1. 字型：CreateFontIndirectA 強制 GBK 字元集；字型名稱/粗細/字高由 ChihanaGBK.ini 調整（含 Lib\Graphics.dll）
2. WideCharToMultiByte(CP_THREAD_ACP)：預設 932（資源名維持 Shift-JIS）；params.dat 的標題/品牌/預設姓名讀取期間 936(GBK)
3. 】【 與全形空白(81 40 / 20 81 40) 改成 GBK 碼（修正視窗標題中間多出的 ㄎ/丂）
4. 載入時自動掃描 params 讀取點與標點字串位址

【排查】ini 的 Debug=1（hook 狀態與掃描結果）、Debug=2（另記錄 params 字串轉碼與視窗標題位元組）；log 在遊戲資料夾 ChihanaGBK.log。

【編譯】source\ 內，32 位元 MinGW（版本資源由 chihana_version.h / chihana_gbk.rc 產生）：
  i686-w64-mingw32-windres -c 65001 -O coff -i chihana_gbk.rc -o chihana_gbk_res.o
  i686-w64-mingw32-gcc -O2 -s -shared -o version.dll chihana_gbk.c chihana_gbk_res.o -Wl,--kill-at -static-libgcc -lkernel32
